import {
  AfterViewInit,
  Component,
  ElementRef,
  HostListener,
  QueryList,
  ViewChildren
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {
  WordsService,
  Pair
} from '../../servicios/words.service';

interface WordItem {
  id: number;
  text: string;
  image?: string;
}

interface Connection {
  leftId: number;
  rightId: number;
  correct: boolean;
}

interface Line {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  correct: boolean;
}

@Component({
  selector: 'app-relation-game',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './relation-game.component.html',
  styleUrls: ['./relation-game.component.css']
})
export class RelationGameComponent implements AfterViewInit {
getPairErrorCount(arg0: any) {
throw new Error('Method not implemented.');
}
showingCorrectWords: any;
correctWords: any;
showingErrorWords: any;
wordsWithErrors: any;
closeResultsDetail() {
throw new Error('Method not implemented.');
}
totalCorrectWords: any;
totalWordsWithErrors: any;
showResultsDetail: any;
showCorrectWords() {
throw new Error('Method not implemented.');
}
showErrorWords() {
throw new Error('Method not implemented.');
}
closeImage() {
throw new Error('Method not implemented.');
}
openImage(arg0: string) {
throw new Error('Method not implemented.');
}
selectedImage: any;
changeCategory() {
throw new Error('Method not implemented.');
}
selectCategoryAndStart() {
throw new Error('Method not implemented.');
}

  // =========================================================
  // LISTA COMPLETA DE PALABRAS
  // =========================================================

  pairs: Pair[] = [];

  // =========================================================
  // CONFIGURACIÓN DEL JUEGO
  // =========================================================

  readonly rowsPerPage = 6;

  readonly maxErrors = 10;

  errors = 0;

  currentPage = 0;

  selectedPairCount = 12;

  gamePairs: Pair[] = [];

  pages: Pair[][] = [];

  leftWords: WordItem[][] = [];

  rightWords: WordItem[][] = [];

  connections: Connection[] = [];

  selectedLeft: WordItem | null = null;

  lines: Line[] = [];

  finished = false;

  gameWon = false;

  changingPage = false;

  // =========================================================
  // BUSCADOR
  // =========================================================

  searchTerm = '';

  // =========================================================
  // PISTAS
  // =========================================================

  showHints = false;

  hints: Pair[] = [];

  private hintTimer: any;

  @ViewChildren('leftButton')
  leftButtons!: QueryList<ElementRef<HTMLElement>>;

  @ViewChildren('rightButton')
  rightButtons!: QueryList<ElementRef<HTMLElement>>;
categorySelected: any;
loadingWords: any;
loadError: any;
selectedCategory: any;
categories: any;

  constructor(
    private wordsService: WordsService
  ) {
    this.pairs = this.wordsService.pairs;
    
    // Aseguramos que la cantidad inicial
    // no sea mayor al total de palabras
    this.selectedPairCount =
      Math.min(
        this.selectedPairCount,
        this.pairs.length
      );

    this.startGame();
  }

  ngAfterViewInit(): void {

    setTimeout(() => {
      this.drawLines();
    });
  }

  // =========================================================
  // BUSCADOR
  // =========================================================

  get filteredPairs(): Pair[] {

    const term =
      this.searchTerm
        .trim()
        .toLowerCase();

    if (!term) {
      return this.pairs;
    }

    return this.pairs.filter(
      pair =>
        pair.left
          .toLowerCase()
          .includes(term) ||

        pair.right
          .toLowerCase()
          .includes(term)
    );
  }

  // =========================================================
  // INICIAR / REINICIAR JUEGO
  // =========================================================

  startGame(): void {

    this.closeHints();

    this.errors = 0;

    this.currentPage = 0;

    this.connections = [];

    this.selectedLeft = null;

    this.finished = false;

    this.gameWon = false;

    this.changingPage = false;

    this.lines = [];

    // =====================================================
    // VALIDAR CANTIDAD SELECCIONADA
    // =====================================================

    if (
      !this.selectedPairCount ||
      this.selectedPairCount < 1
    ) {
      this.selectedPairCount = 1;
    }

    if (
      this.selectedPairCount >
      this.pairs.length
    ) {
      this.selectedPairCount =
        this.pairs.length;
    }

    // =====================================================
    // MEZCLAR TODA LA LISTA
    // =====================================================

    const shuffledAllPairs =
      this.shuffle([
        ...this.pairs
      ]);

    // =====================================================
    // TOMAR SOLO LA CANTIDAD SELECCIONADA
    // =====================================================

    this.gamePairs =
      shuffledAllPairs.slice(
        0,
        this.selectedPairCount
      );

    // =====================================================
    // CREAR PÁGINAS DE MÁXIMO 6 PAREJAS
    // =====================================================

    this.pages =
      this.chunk(
        this.gamePairs,
        this.rowsPerPage
      );

    this.leftWords = [];

    this.rightWords = [];

    // =====================================================
    // MEZCLAR CADA COLUMNA
    // =====================================================

    this.pages.forEach(page => {

      const left: WordItem[] =
        page.map(pair => ({
          id: pair.id,
          text: pair.left,
          // +" - "+pair.meaning,
          image: pair.image
        }));

      const right: WordItem[] =
        page.map(pair => ({
          id: pair.id,
          text: pair.right,
        }));

      this.leftWords.push(
        this.shuffle(left)
      );

      this.rightWords.push(
        this.shuffle(right)
      );
    });

    setTimeout(() => {
      this.drawLines();
    });
  }

  // =========================================================
  // SELECCIONAR PALABRA IZQUIERDA
  // =========================================================

  selectLeft(word: WordItem): void {

    if (
      this.finished ||
      this.changingPage ||
      this.showHints
    ) {
      return;
    }

    if (
      this.isLeftConnected(word.id)
    ) {
      return;
    }

    this.selectedLeft = word;
  }

  // =========================================================
  // SELECCIONAR PALABRA DERECHA
  // =========================================================

  selectRight(word: WordItem): void {

    if (
      this.finished ||
      this.changingPage ||
      this.showHints ||
      !this.selectedLeft
    ) {
      return;
    }

    if (
      this.isRightConnected(word.id)
    ) {
      return;
    }

    const left =
      this.selectedLeft;

    const correct =
      left.id === word.id;

    // =====================================================
    // RESPUESTA CORRECTA
    // =====================================================

    if (correct) {

      this.connections.push({
        leftId: left.id,
        rightId: word.id,
        correct: true
      });

      this.selectedLeft = null;

      setTimeout(() => {

        this.drawLines();

        this.checkCurrentPageComplete();

      }, 100);

      return;
    }

    // =====================================================
    // RESPUESTA INCORRECTA
    // SOLO AQUÍ SE DESCUENTA UN INTENTO
    // =====================================================

    this.errors++;

    this.connections.push({
      leftId: left.id,
      rightId: word.id,
      correct: false
    });

    this.selectedLeft = null;

    setTimeout(() => {
      this.drawLines();
    });

    // Mostrar la línea roja temporalmente
    setTimeout(() => {

      this.connections =
        this.connections.filter(
          connection =>
            !(
              connection.leftId === left.id &&
              connection.rightId === word.id &&
              connection.correct === false
            )
        );

      this.drawLines();

    }, 700);

    // =====================================================
    // SI LLEGA A 10 ERRORES
    // =====================================================

    if (
      this.errors >=
      this.maxErrors
    ) {

      setTimeout(() => {

        this.finished = true;

        this.gameWon = false;

      }, 750);
    }
  }

  // =========================================================
  // COMPROBAR SI LA PÁGINA ACTUAL ESTÁ COMPLETA
  // =========================================================

  checkCurrentPageComplete(): void {

    if (
      this.finished ||
      this.changingPage
    ) {
      return;
    }

    const currentPairs =
      this.pages[
        this.currentPage
      ];

    if (!currentPairs) {
      return;
    }

    const pageComplete =
      currentPairs.every(
        pair =>
          this.connections.some(
            connection =>
              connection.correct &&
              connection.leftId ===
                pair.id &&
              connection.rightId ===
                pair.id
          )
      );

    if (!pageComplete) {
      return;
    }

    // =====================================================
    // SI ES LA ÚLTIMA PÁGINA
    // =====================================================

    if (
      this.currentPage ===
      this.pages.length - 1
    ) {

      this.finished = true;

      this.gameWon = true;

      return;
    }

    // =====================================================
    // PASAR AUTOMÁTICAMENTE
    // =====================================================

    this.changingPage = true;

    setTimeout(() => {

      this.currentPage++;

      this.selectedLeft = null;

      this.lines = [];

      this.changingPage = false;

      setTimeout(() => {
        this.drawLines();
      });

    }, 700);
  }

  // =========================================================
  // PISTAS
  // =========================================================

  showHintsPanel(): void {

    if (
      this.finished ||
      this.changingPage
    ) {
      return;
    }

    // Cancelar un temporizador anterior
    if (this.hintTimer) {
      clearTimeout(
        this.hintTimer
      );
    }

    const currentPairs =
      this.pages[
        this.currentPage
      ] ?? [];

    // Obtener únicamente las parejas
    // todavía no resueltas
    const pendingPairs =
      currentPairs.filter(
        pair =>
          !this.connections.some(
            connection =>
              connection.correct &&
              connection.leftId ===
                pair.id &&
              connection.rightId ===
                pair.id
          )
      );

    if (
      pendingPairs.length === 0
    ) {
      return;
    }

    this.hints =
      this.shuffle([
        ...pendingPairs
      ]).slice(
        0,
        6
      );

    this.showHints = true;

    // Cerrar después de 5 segundos
    this.hintTimer =
      setTimeout(() => {

        this.showHints = false;

        this.hints = [];

      }, 5000);
  }

  closeHints(): void {

    this.showHints = false;

    this.hints = [];

    if (this.hintTimer) {

      clearTimeout(
        this.hintTimer
      );

      this.hintTimer = null;
    }
  }

  // =========================================================
  // ESTADO DE PALABRAS
  // =========================================================

  isLeftConnected(
    id: number
  ): boolean {

    return this.connections.some(
      connection =>
        connection.leftId === id &&
        connection.correct
    );
  }

  isRightConnected(
    id: number
  ): boolean {

    return this.connections.some(
      connection =>
        connection.rightId === id &&
        connection.correct
    );
  }

  isSelected(
    id: number
  ): boolean {

    return (
      this.selectedLeft?.id === id
    );
  }

  // =========================================================
  // CONTADORES
  // =========================================================

  get correctAnswers(): number {

    return this.connections.filter(
      connection =>
        connection.correct
    ).length;
  }

  get remainingAttempts(): number {

    return Math.max(
      this.maxErrors -
      this.errors,
      0
    );
  }

  get totalPages(): number {

    return this.pages.length;
  }

  get currentPageCorrectAnswers(): number {

    const page =
      this.pages[
        this.currentPage
      ];

    if (!page) {
      return 0;
    }

    return page.filter(
      pair =>
        this.connections.some(
          connection =>
            connection.correct &&
            connection.leftId ===
              pair.id &&
            connection.rightId ===
              pair.id
        )
    ).length;
  }

  // =========================================================
  // DIBUJAR LÍNEAS
  // =========================================================

  drawLines(): void {

    if (
      !this.leftButtons ||
      !this.rightButtons
    ) {
      return;
    }

    const newLines: Line[] = [];

    const currentIds =
      this.pages[
        this.currentPage
      ]?.map(
        pair => pair.id
      ) ?? [];

    const visibleConnections =
      this.connections.filter(
        connection =>
          currentIds.includes(
            connection.leftId
          )
      );

    const boardElement =
      document.querySelector(
        '.game-board'
      );

    if (!boardElement) {
      return;
    }

    const board =
      boardElement
        .getBoundingClientRect();

    visibleConnections.forEach(
      connection => {

        const leftElement =
          this.leftButtons.find(
            button =>
              Number(
                button
                  .nativeElement
                  .dataset['id']
              ) ===
              connection.leftId
          );

        const rightElement =
          this.rightButtons.find(
            button =>
              Number(
                button
                  .nativeElement
                  .dataset['id']
              ) ===
              connection.rightId
          );

        if (
          !leftElement ||
          !rightElement
        ) {
          return;
        }

        const leftRect =
          leftElement
            .nativeElement
            .getBoundingClientRect();

        const rightRect =
          rightElement
            .nativeElement
            .getBoundingClientRect();

        newLines.push({

          x1:
            leftRect.right -
            board.left,

          y1:
            leftRect.top -
            board.top +
            leftRect.height / 2,

          x2:
            rightRect.left -
            board.left,

          y2:
            rightRect.top -
            board.top +
            rightRect.height / 2,

          correct:
            connection.correct
        });
      }
    );

    this.lines =
      newLines;
  }

  // =========================================================
  // REDIBUJAR AL CAMBIAR TAMAÑO
  // =========================================================

  @HostListener(
    'window:resize'
  )
  onResize(): void {

    setTimeout(() => {
      this.drawLines();
    });
  }

  // =========================================================
  // MEZCLAR ARRAY
  // =========================================================

  shuffle<T>(
    array: T[]
  ): T[] {

    const result =
      [...array];

    for (
      let i =
        result.length - 1;
      i > 0;
      i--
    ) {

      const j =
        Math.floor(
          Math.random() *
          (i + 1)
        );

      [
        result[i],
        result[j]
      ] = [
        result[j],
        result[i]
      ];
    }

    return result;
  }

  // =========================================================
  // DIVIDIR EN PÁGINAS
  // =========================================================

  chunk<T>(
    array: T[],
    size: number
  ): T[][] {

    const result: T[][] =
      [];

    for (
      let i = 0;
      i < array.length;
      i += size
    ) {

      result.push(
        array.slice(
          i,
          i + size
        )
      );
    }

    return result;
  }
}