import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

import {
  WordsService,
  Pair
} from '../../servicios/words.service';

interface LetterCell {
isSpace: any;
  letter: string;
  hidden: boolean;
  value: string;
  correct: boolean | null;
}

interface ExercisePair {
  id: number;

  leftOriginal: string;
  rightOriginal: string;

  leftCells: LetterCell[];
  rightCells: LetterCell[];

  completed: boolean;
}

@Component({
  selector: 'app-completar-palabras',

  standalone: true,

  imports: [CommonModule, FormsModule],

  templateUrl: './completar-palabras.component.html',

  styleUrls: ['./completar-palabras.component.css'],
})
export class CompletarPalabrasComponent {
totalCorrectWords: any;
totalWordsWithErrors: any;
showResultsDetail: any;
correctWords: any;
showingErrorWords: any;
wordsWithErrors: any;
showErrorWords() {
throw new Error('Method not implemented.');
}
showCorrectWords() {
throw new Error('Method not implemented.');
}
selectCategoryAndStart() {
throw new Error('Method not implemented.');
}
changeCategory() {
throw new Error('Method not implemented.');
}
categorySelected: any;
loadingWords: any;
loadError: any;
allPairs: any;
selectedCategory: any;
ALL_CATEGORIES: any;
categories: any;
closeResultsDetail() {
throw new Error('Method not implemented.');
}

  // =========================================================
  // LISTA DE PALABRAS
  // =========================================================

  pairs: Pair[] = [];

  // =========================================================
  // CONFIGURACIÓN DEL JUEGO
  // =========================================================

  readonly wordsPerPage = 6;

  readonly maxErrors = 10;

  selectedPairCount = 12;

  currentPage = 0;

  errors = 0;

  exercises: ExercisePair[] = [];

  pages: ExercisePair[][] = [];

  gameFinished = false;

  gameWon = false;

  changingPage = false;

  // =========================================================
  // BUSCADOR
  // =========================================================

  searchTerm = '';

  // =========================================================
  // PISTAS
  // =========================================================

  showHints = false;

  hints: Pair[] = [];

  private hintTimer: any;

  // =========================================================
  // PORCENTAJE DE LETRAS OCULTAS
  // =========================================================

  hiddenPercentage = 0.45;

  // =========================================================
  // CONSTRUCTOR
  // =========================================================

  constructor(
    private wordsService: WordsService
  ) {
    this.pairs = this.wordsService.pairs;

    this.startGame();
  }

  // =========================================================
  // INICIAR JUEGO
  // =========================================================

  startGame(): void {

    // Cerramos pistas si estaban abiertas

    this.closeHints();

    // Reiniciar valores

    this.errors = 0;

    this.currentPage = 0;

    this.gameFinished = false;

    this.gameWon = false;

    this.changingPage = false;

    // =====================================================
    // VALIDAR CANTIDAD DE PAREJAS
    // =====================================================

    if (!this.selectedPairCount || this.selectedPairCount < 1) {
      this.selectedPairCount = 1;
    }

    if (this.selectedPairCount > this.pairs.length) {
      this.selectedPairCount = this.pairs.length;
    }

    // =====================================================
    // MEZCLAR LAS PAREJAS
    //
    // IMPORTANTE:
    // Cada verbo sigue junto a su pareja.
    //
    // Ejemplo:
    // drive -> drove
    //
    // Nunca se separan.
    // Solo cambia el orden de aparición.
    // =====================================================

    const selectedPairs = this.shuffle([...this.pairs]).slice(
      0,
      this.selectedPairCount,
    );

    // =====================================================
    // CREAR EJERCICIOS
    // =====================================================

    this.exercises = selectedPairs.map((pair) => ({
      id: pair.id,

      leftOriginal: pair.left,

      rightOriginal: pair.right,

      leftCells: this.createWordCells(pair.left),

      rightCells: this.createWordCells(pair.right),

      completed: false,
    }));

    // =====================================================
    // DIVIDIR EN PÁGINAS
    // =====================================================

    this.pages = this.chunk(
      this.exercises,
      this.wordsPerPage
    );
  }

  // =========================================================
  // CREAR LOS ESPACIOS DE UNA PALABRA
  // =========================================================

  createWordCells(word: string): LetterCell[] {

    const letters = word.split('');

    // =====================================================
    // CUÁNTAS LETRAS OCULTAR
    // =====================================================

    let numberToHide =
      Math.round(
        letters.length *
        this.hiddenPercentage
      );

    // Debe ocultarse al menos una letra

    if (numberToHide < 1) {
      numberToHide = 1;
    }

    // Evitar ocultar toda la palabra

    if (numberToHide >= letters.length) {
      numberToHide = letters.length - 1;
    }

    // Si la palabra tiene una sola letra

    if (letters.length === 1) {
      numberToHide = 1;
    }

    // =====================================================
    // CREAR ÍNDICES
    // =====================================================

    const indexes =
      letters.map(
        (_, index) => index
      );

    // =====================================================
    // MEZCLAR POSICIONES DE LETRAS
    // =====================================================

    const shuffledIndexes =
      this.shuffle(indexes);

    const hiddenIndexes =
      new Set(
        shuffledIndexes.slice(
          0,
          numberToHide
        )
      );

    // =====================================================
    // CREAR CELDAS
    // =====================================================

    return letters.map(
      (letter, index) => ({
        letter,

        hidden:
          hiddenIndexes.has(index),

        value: '',

        correct: null,
      })
    );
  }

  // =========================================================
  // CUANDO EL ESTUDIANTE ESCRIBE UNA LETRA
  // =========================================================

  onLetterInput(
    cell: LetterCell,
    event: Event,
    exercise: ExercisePair
  ): void {

    if (
      this.gameFinished ||
      exercise.completed ||
      this.changingPage ||
      this.showHints
    ) {
      return;
    }

    const input =
      event.target as HTMLInputElement;

    // =====================================================
    // SOLO TOMAR UNA LETRA
    // =====================================================

    let value =
      input.value
        .slice(-1)
        .toLowerCase();

    // =====================================================
    // SOLO LETRAS
    // =====================================================

    value =
      value.replace(
        /[^a-záéíóúüñ]/gi,
        ''
      );

    cell.value = value;

    input.value = value;

    // =====================================================
    // SI ESTÁ VACÍO
    // =====================================================

    if (!value) {

      cell.correct = null;

      return;
    }

    // =====================================================
    // RESPUESTA CORRECTA
    // =====================================================

    if (
      value ===
      cell.letter.toLowerCase()
    ) {

      cell.correct = true;

      this.checkExerciseComplete(
        exercise
      );

      // ===================================================
      // PASAR AUTOMÁTICAMENTE AL SIGUIENTE INPUT
      // ===================================================

      setTimeout(() => {

        this.focusNextLetter(
          input
        );

      }, 50);

      return;
    }

    // =====================================================
    // RESPUESTA INCORRECTA
    // =====================================================

    cell.correct = false;

    // Solo los errores descuentan intento

    this.errors++;

    // =====================================================
    // LIMPIAR RESPUESTA INCORRECTA
    // =====================================================

    setTimeout(() => {

      if (
        cell.correct === false
      ) {

        cell.value = '';

        cell.correct = null;

        // Mantener el cursor
        // en la misma casilla

        input.focus();
      }

    }, 500);

    // =====================================================
    // SE ACABARON LOS INTENTOS
    // =====================================================

    if (
      this.errors >=
      this.maxErrors
    ) {

      setTimeout(() => {

        this.gameFinished = true;

        this.gameWon = false;

      }, 500);
    }
  }

  // =========================================================
  // PASAR AUTOMÁTICAMENTE A LA SIGUIENTE LETRA
  // =========================================================

  focusNextLetter(
    currentInput: HTMLInputElement
  ): void {

    const inputs = Array.from(

      document.querySelectorAll<HTMLInputElement>(
        '.letter-input:not(:disabled)'
      )

    );

    const currentIndex =
      inputs.indexOf(
        currentInput
      );

    if (
      currentIndex !== -1 &&
      currentIndex <
      inputs.length - 1
    ) {

      const nextInput =
        inputs[
          currentIndex + 1
        ];

      nextInput.focus();

      nextInput.select();
    }
  }

  // =========================================================
  // COMPROBAR SI UNA PAREJA ESTÁ COMPLETA
  // =========================================================

  checkExerciseComplete(
    exercise: ExercisePair
  ): void {

    const leftComplete =
      exercise.leftCells.every(
        (cell) =>
          !cell.hidden ||
          cell.correct === true
      );

    const rightComplete =
      exercise.rightCells.every(
        (cell) =>
          !cell.hidden ||
          cell.correct === true
      );

    exercise.completed =
      leftComplete &&
      rightComplete;

    if (
      exercise.completed
    ) {

      this.checkPageComplete();
    }
  }

  // =========================================================
  // MOSTRAR PISTAS
  // =========================================================

  showHintsPanel(): void {

    if (
      this.gameFinished ||
      this.changingPage
    ) {
      return;
    }

    // Cancelar temporizador anterior

    if (
      this.hintTimer
    ) {

      clearTimeout(
        this.hintTimer
      );
    }

    // =====================================================
    // EJERCICIOS DE LA PÁGINA ACTUAL
    // =====================================================

    const currentExercises =
      this.pages[
        this.currentPage
      ] ?? [];

    // =====================================================
    // SOLO PAREJAS NO COMPLETADAS
    // =====================================================

    const pendingExercises =
      currentExercises.filter(
        (exercise) =>
          !exercise.completed
      );

    // =====================================================
    // CREAR LISTA DE PISTAS
    // =====================================================

    this.hints =
      pendingExercises
        .map(
          (exercise) => {

            const pair =
              this.pairs.find(
                (pair) =>
                  pair.id ===
                  exercise.id
              );

            return {

              id:
                exercise.id,

              left:
                exercise.leftOriginal,

              right:
                exercise.rightOriginal,

              meaning:
                pair?.meaning ?? '',
            };

          }
        )
        .slice(
          0,
          6
        );

    // Si no hay pendientes

    if (
      this.hints.length === 0
    ) {
      return;
    }

    // Mostrar panel

    this.showHints = true;

    // =====================================================
    // CERRAR AUTOMÁTICAMENTE EN 5 SEGUNDOS
    // =====================================================

    this.hintTimer =
      setTimeout(() => {

        this.showHints = false;

        this.hints = [];

        this.hintTimer = null;

      }, 50000);
  }

  // =========================================================
  // CERRAR PISTAS
  // =========================================================

  closeHints(): void {

    this.showHints = false;

    this.hints = [];

    if (
      this.hintTimer
    ) {

      clearTimeout(
        this.hintTimer
      );

      this.hintTimer = null;
    }
  }

  // =========================================================
  // COMPROBAR SI TERMINÓ LA PÁGINA
  // =========================================================

  checkPageComplete(): void {

    const page =
      this.pages[
        this.currentPage
      ];

    if (!page) {
      return;
    }

    const complete =
      page.every(
        (exercise) =>
          exercise.completed
      );

    if (!complete) {
      return;
    }

    // =====================================================
    // SI ES LA ÚLTIMA PÁGINA
    // =====================================================

    if (
      this.currentPage ===
      this.pages.length - 1
    ) {

      this.gameFinished = true;

      this.gameWon = true;

      return;
    }

    // =====================================================
    // CAMBIAR AUTOMÁTICAMENTE
    // =====================================================

    this.changingPage = true;

    setTimeout(() => {

      this.currentPage++;

      this.changingPage = false;

      // Poner el cursor en el primer espacio
      // de la nueva página

      setTimeout(() => {

        const firstInput =
          document.querySelector<HTMLInputElement>(
            '.letter-input:not(:disabled)'
          );

        firstInput?.focus();

      }, 50);

    }, 800);
  }

  // =========================================================
  // TOTAL DE PÁGINAS
  // =========================================================

  get totalPages(): number {

    return this.pages.length;
  }

  // =========================================================
  // INTENTOS RESTANTES
  // =========================================================

  get remainingAttempts(): number {

    return Math.max(
      this.maxErrors -
      this.errors,
      0
    );
  }

  // =========================================================
  // PAREJAS COMPLETADAS
  // =========================================================

  get completedPairs(): number {

    return this.exercises.filter(
      (exercise) =>
        exercise.completed
    ).length;
  }

  // =========================================================
  // PAREJAS COMPLETADAS EN LA PÁGINA ACTUAL
  // =========================================================

  get currentPageCompleted(): number {

    const page =
      this.pages[
        this.currentPage
      ];

    if (!page) {
      return 0;
    }

    return page.filter(
      (exercise) =>
        exercise.completed
    ).length;
  }

  // =========================================================
  // BUSCADOR
  // =========================================================

  get filteredPairs(): Pair[] {

    const term =
      this.searchTerm
        .trim()
        .toLowerCase();

    if (!term) {

      return this.pairs;
    }

    return this.pairs.filter(
      (pair) =>

        pair.left
          .toLowerCase()
          .includes(term) ||

        pair.right
          .toLowerCase()
          .includes(term)
    );
  }

  // =========================================================
  // MEZCLAR
  // =========================================================

  shuffle<T>(
    array: T[]
  ): T[] {

    const result =
      [...array];

    for (
      let i =
        result.length - 1;
      i > 0;
      i--
    ) {

      const j =
        Math.floor(
          Math.random() *
          (i + 1)
        );

      [
        result[i],
        result[j]
      ] = [
        result[j],
        result[i]
      ];
    }

    return result;
  }

  // =========================================================
  // DIVIDIR EN PÁGINAS
  // =========================================================

  chunk<T>(
    array: T[],
    size: number
  ): T[][] {

    const result: T[][] =
      [];

    for (
      let i = 0;
      i < array.length;
      i += size
    ) {

      result.push(
        array.slice(
          i,
          i + size
        )
      );
    }

    return result;
  }
}